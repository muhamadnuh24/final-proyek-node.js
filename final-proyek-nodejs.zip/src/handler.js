const { nanoid } = require('nanoid');
const books = require('./books');

const addBookHandler = (request, h) => {
    const { name, year, author, summary, publisher, pageCount, readPage, reading } = request.payload;
  
    const id = nanoid(16);
    const insertedAt = new Date().toISOString();
    const updatedAt = insertedAt;
    const finished = false;
  
    const newBook = {
      id, name, year, author,summary, publisher, pageCount, readPage, finished, reading, insertedAt, updatedAt,
    };
  
    books.push(newBook);
  
    const isSuccess = books.filter((book) => book.id === id).length > 0;

    // Validasi properti 'name'
    if (!name) {
        const response = h.response({
            status: 'fail',
            message: 'Gagal menambahkan buku. Mohon isi nama buku',
        });
        response.code(400);
        return response;
    }

    // Validasi properti 'readPage' > pageCount
    if (readPage > pageCount) {
        const response = h.response({
            status: 'fail',
            message: 'Gagal menambahkan buku. readPage tidak boleh lebih besar dari pageCount',
        });
        response.code(400);
        return response;
    }

    if (isSuccess) {
      const response = h.response({
        status: 'success',
        message: 'Buku berhasil ditambahkan',
        data: {
          bookId: id,
        },
      });
      response.code(201);
      return response;
    }
  
    const response = h.response({
      status: 'fail',
      message: 'Buku gagal ditambahkan',
    });
    response.code(500);
    return response;
  };

  const getAllBooksHandler = (request, h) => {

    const { name, reading, finished } = request.query; // Ambil parameter query "name"
    
    let filteredBooks = books; // Default: semua buku
    if (name) {
        const lowerCaseName = name.toLowerCase(); // Konversi query ke huruf kecil
        filteredBooks = books.filter((book) => 
            book.name.toLowerCase().includes(lowerCaseName) // Cocokkan nama buku secara non-case sensitive
        );
    }

    // Filter berdasarkan query "reading" (0 atau 1)
    console.log(reading);
    if (reading !== undefined) {
        const isReading = reading === '1'; // Konversi 1 -> true, 0 -> false
        console.log(isReading);
        filteredBooks = filteredBooks.filter((book) => book.reading === isReading);
        console.log(filteredBooks);
    }

    // Filter berdasarkan query "finished" (0 atau 1)
    if (finished !== undefined) {
        const isFinished = finished === '1'; // Konversi 1 -> true, 0 -> false
        filteredBooks = filteredBooks.filter((book) => book.finished === isFinished);
    }

    const booksSummary = filteredBooks.map((book) => ({
        id: book.id,
        name: book.name,
        publisher: book.publisher,
    }));

    return {
        status: 'success',
        data: {
            books: booksSummary,
        },
    };
};

  const getBookByIdHandler = (request, h) => {
    const { id } = request.params;

    
    const booksCollection = books.map((book) => ({
        id: book.id,
        name: book.name,
        publisher: book.publisher,
    }));

    const book = booksCollection.filter((n) => n.id === id);

    //const book = books.find((n) => n.id === id);

    
  
    if (book.length > 0) {
      return {
        status: 'success',
        data: {
            book,
        },
      };
    }
  
    const response = h.response({
      status: 'fail',
      message: 'Buku tidak ditemukan',
    });

    response.code(404);
    return response;
  };

  const editBookByIdHandler = (request, h) => {
    const { id } = request.params;
  
    const { name, year, author, summary, publisher, pageCount, readPage, reading } = request.payload;
    const updatedAt = new Date().toISOString();
  
    const index = books.findIndex((book) => book.id === id);

    console.log(name);

    if (!name) {
        const response = h.response({
            status: 'fail',
            message: 'Name required',
        });
        response.code(400);
        return response;
    }

    if (readPage > pageCount) {
        const response = h.response({
            status: 'fail',
            message: 'Gagal menambahkan buku. readPage tidak boleh lebih besar dari pageCount',
        });
        response.code(400);
        return response;
    }
  
    if (index !== -1) {
        books[index] = {
        ...books[index],
        name,
        year,
        author,
        summary,
        publisher,
        pageCount,
        readPage,
        reading,
      };
  
      const response = h.response({
        status: 'success',
        message: 'Buku berhasil diperbarui',
      });
      response.code(200);
      return response;
    }
  
    const response = h.response({
      status: 'fail',
      message: 'Gagal memperbarui buku. Id tidak ditemukan',
    });
    response.code(404);
    return response;
  };

  const deleteBookByIdHandler = (request, h) => {
    const { id } = request.params;
  
    const index = books.findIndex((book) => book.id === id);
  
    if (index !== -1) {
        books.splice(index, 1);
      const response = h.response({
        status: 'success',
        message: 'Buku berhasil dihapus',
      });
      response.code(200);
      return response;
    }
  
    const response = h.response({
      status: 'fail',
      message: 'Buku gagal dihapus. Id tidak ditemukan',
    });
    response.code(404);
    return response;
  };

module.exports = { addBookHandler, getAllBooksHandler, getBookByIdHandler, editBookByIdHandler, deleteBookByIdHandler };